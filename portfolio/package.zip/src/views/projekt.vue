<template>
  <div class="about">
    <div id="projekterne">
      <div class="overksriftFlexBoks">
        <button @click="hideAndSeek()">klik her</button>
        <h1 class="overskriftSize">Projekter</h1>
      </div>
      <div>
        <div class="OuterBoks">
          <!------------------------------------------------->
          <!--                 side menu                   -->
          <!------------------------------------------------->
          <div :style="sidemenuBoks">
            <div :style="css">

              <div>
                <button @click="hideAndSeek('projektType')" class="hideAndSeekButtom">Projekt type</button>
                <div :style="projektTypeCss" >
                    <ul  class="hideAndSeekBoks">
                        <li v-for="projektTypen in projektType" :key="projektTypen.id">
                            <input type="checkbox" @click="test('projekt_type-' + projektTypen.id)"><label> {{ projektTypen.name }} </label>
                        </li>
                    </ul>
                </div>
              </div>

              <div>
                <button @click="hideAndSeek('arbejdsType')" class="hideAndSeekButtom">Arbejds type</button>
                <div :style="arbejdsTypeCss" >
                    <ul  class="hideAndSeekBoks">
                        <li v-for="arbejdsTypen in arbejdsType" :key="arbejdsTypen.id">
                            <input type="checkbox" @click="test('arbejds_type-' + arbejdsTypen.id), test1(arbejdsTypen.id, 'arbejdstype')" :id="'arbejdstype' + arbejdsTypen.id"><label> {{ arbejdsTypen.name }} </label>
                        </li>
                    </ul>
                </div>
              </div>

              <div>
                <button @click="hideAndSeek('software')" class="hideAndSeekButtom">Software</button>
                <div :style="softwareCss" >
                    <ul  class="hideAndSeekBoks">
                        <li v-for="softwaret in software" :key="softwaret.id">
                            <input type="checkbox" @click="test('software-' + softwaret.id), test1(softwaret.id, 'software')" :id="'software' + softwaret.id"><label> {{ softwaret.name }} </label>
                        </li>
                    </ul>
                </div>
              </div>

              <div>
                <button @click="hideAndSeek('diagram')" class="hideAndSeekButtom">Diagrammer</button>
                <div :style="diagramCss">
                    <ul  class="hideAndSeekBoks">
                        <li  v-for="diagrammet in diagram" :key="diagrammet.id">
                            <input type="checkbox" @click="test('diagrammer-' + diagrammet.id)"><label> {{ diagrammet.name }} </label>
                        </li>
                    </ul>
                </div>
              </div>

              <div>
                <button @click="hideAndSeek('sprog')" class="hideAndSeekButtom">sprog</button>
                <div :style="sprogCss">
                    <ul  class="hideAndSeekBoks">
                        <li v-for="sproget in sprog" :key="sproget.id">
                            <input type="checkbox" @click="test('sprog-' + sproget.id)"><label> {{ sproget.name }} </label>
                        </li>
                    </ul>
                </div>
              </div>
            </div>
          </div>

          <!------------------------------------------------->
          <!--                 Projekterne                 -->
          <!------------------------------------------------->
          <div :style="projekterneBoks">

            <!-- skal tilbage igen  -->
            <!-- <div  class="OuterBoksFlex">
              <div :id="getId(index % 12)" v-for="(project, index) in allProjects" :key="index" :class="getClass(index % 12)">
                <img :src="project.images[1]" :alt="project.images[2]" class="imagesSize">
                <p></p>
              </div>
            </div> -->


            <div class="OuterBoksFlex">
              <div class="boks1-100" id="boks1">
                <p class="tekst1-100" id="tekst1">hej</p>
                <div class="triangle1-100" id="triangle1"></div>
              </div>
              <div class="boks2-100" id="boks2">
                <p class="tekst2-100" id="tekst2">hej</p>
                <div class="triangle2-100" id="triangle2"></div>
              </div>
              <div class="boks3-100" id="boks3">
                <p class="tekst3-100" id="tekst3">hej</p>
                <div class="triangle3-100" id="triangle3"></div>
              </div>
              <div class="boks4-100" id="boks4">
                <p class="tekst4-100" id="tekst4">hej</p>
                <div class="triangle4-100" id="triangle4"></div>
              </div>
              <div class="boks5-100" id="boks5">
                <p class="tekst5-100" id="tekst5">hej</p>
                <div class="triangle5-100" id="triangle5"></div>
              </div>
              <div class="boks6-100" id="boks6">
                <p class="tekst6-100" id="tekst6">hej</p>
                <div class="triangle6-100" id="triangle6"></div>
              </div>
              <div class="boks7-100" id="boks7">
                <p class="tekst7-100" id="tekst7">hej</p>
                <div class="triangle7-100" id="triangle7"></div>
              </div>
              <div class="boks8-100" id="boks8">
                <p class="tekst8-100" id="tekst8">hej</p>
                <div class="triangle8-100" id="triangle8"></div>
              </div>
              <div class="boks9-100" id="boks9">
                <p class="tekst9-100" id="tekst9">hej</p>
                <div class="triangle9-100" id="triangle9"></div>
              </div>
              <div class="boks10-100" id="boks10">
                <p class="tekst10-100" id="tekst10">hej</p>
                <div class="triangle10-100" id="triangle10"></div>
                </div>
              <div class="boks11-100" id="boks11">
                <p class="tekst11-100" id="tekst11">hej</p>
                <div class="triangle11-100" id="triangle11"></div>
                </div>
              <div class="boks12-100" id="boks12">
                <p class="tekst12-100" id="tekst12">hej</p>
                <div class="triangle12-100" id="triangle12"></div>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'

  export default {
    name: 'forside', 
    components: {
    },
    data(){
          return{
            css: "display: none;",
            sidemenuBoks: "flex: 0%;",
            projekterneBoks: "flex: 100%;",
            sprogCss: "display: none;",
            diagramCss: "display: none;",
            softwareCss: "display: none;",
            projektTypeCss: "display: none;",
            arbejdsTypeCss: "display: none;",
            sprog: [],
            diagram: [],
            software: [],
            projektType: [],
            arbejdsType: [],
            typeArray: [],
            windowswidth: 0,
            allProjects: [],
            finishProjekt: [],
            searchMenu: []
          }
      },
      created(){
        this.allProject(),
        this.getSprog(),
        this.getDiagram(),
        this.getProjektType(),
        this.getArbejdsType(),
        this.getSoftware(),
        this.imagesShiftSize()
        
      },
      mounted(){
        window.addEventListener('scroll', this.stickNavbar) // laver en event.
        this.$nextTick(function() {
          window.addEventListener('resize', this.getWindowWidth);
          //Init
          this.getWindowWidth()
        })
      },
      methods:{
        allProject(){
          console.log("jeg er her")
          axios
            .get('http://localhost/re-portfolio/API/index.php/api/projekt', {
              headers: {
                'Accept': 'application/json'
              }
            })
            .then(Response => {
              this.allProjects = Response.data
              console.log(this.allProjects)
            })
            .catch(err => {
              console.log(err.toString());
            })
        },
        hideAndSeek(tekst){
          switch (tekst) {
            case "projektType":
              if(this.projektTypeCss == "display: none;"){
                this.projektTypeCss = "display: block;";
              }
              else{
                this.projektTypeCss = "display: none;";
              }
              break;
            case "arbejdsType":
              if(this.arbejdsTypeCss == "display: none;"){
                this.arbejdsTypeCss = "display: block;";
              }
              else{
                this.arbejdsTypeCss = "display: none;";
              }
              break;
            case "software":
              if(this.softwareCss == "display: none;"){
                this.softwareCss = "display: block;";
              }
              else{
                this.softwareCss = "display: none;";
              }
              break;
            case "diagram":
              if(this.diagramCss == "display: none;"){
                this.diagramCss = "display: block;";
              }
              else{
                this.diagramCss = "display: none;";
              }
              break;
            case "sprog":
              if(this.sprogCss == "display: none;"){
                this.sprogCss = "display: block;";
              }
              else{
                this.sprogCss = "display: none;";
              }
              break;
            default:
              if(this.css == "display: none;"){
                this.css = "display: block;";
                this.sidemenuBoks = "flex: 20%;";
                this.projekterneBoks = "flex: 80%;";
                this.imagesShiftSize();
                this.imagestest()
                // this.imagesTextShiftSize();
              }
              else{
                this.css = "display: none;";
                this.sidemenuBoks = "flex: 0%;";
                this.projekterneBoks = "flex: 100%;";
                this.imagesShiftSize();
                this.imagestest()
                // this.imagesTextShiftSize();
              }
              break;
            
          }
        },
        getSprog(){
          axios
            .get('http://localhost/re-portfolio/API/index.php/api/language',{
              headers: {
                'Accept': 'application/json'
              }
            })
            .then(Response => {
              this.sprog = Response.data
              console.log(this.sprog);
            })
            .catch(err => {
              console.log(err.toString());
            })
            // this.allProject()
        },
        getDiagram(){
          axios
            .get('http://localhost/re-portfolio/API/index.php/api/diagram',{
              headers: {
                'Accept': 'application/json'
              }
            })
            .then(Response => {
              this.diagram = Response.data
              console.log(this.diagram);
            })
            .catch(err => {
              console.log(err.toString());
            })
        }, 
        getProjektType(){
          axios
            .get('http://localhost/re-portfolio/API/index.php/api/projekt-type',{
              headers: {
                'Accept': 'application/json'
              }
            })
            .then(Response => {
              this.projektType = Response.data
              console.log(this.projektType);
            })
            .catch(err => {
              console.log(err.toString());
            })
        },
        getArbejdsType(){
          axios
            .get('http://localhost/re-portfolio/API/index.php/api/work-type',{
              headers: {
                'Accept': 'application/json'
              }
            })
            .then(Response => {
              this.arbejdsType = Response.data
              console.log(this.arbejdsType);
            })
            .catch(err => {
              console.log(err.toString());
            })
        },
        getSoftware(){
          axios
            .get('http://localhost/re-portfolio/API/index.php/api/software',{
              headers: {
                'Accept': 'application/json'
              }
            })
            .then(Response => {
              this.software = Response.data
              console.log(this.software);
            })
            .catch(err => {
              console.log(err.toString());
            })
        },
        // test kan godt dynamsik
        test(type){
          console.log("trykkede på " + type);
          let countTypeArray = this.typeArray.length;
          let tjek = 0;


          if(countTypeArray == 0){
            this.typeArray.push(type); 
          }
          else{
          
            for(let i = 0; i < countTypeArray; i++){
              if(type == this.typeArray[i]){
                delete this.typeArray[i];

                // gør at der ikke er nogen empty variabler i arrayet
                this.typeArray = this.typeArray.filter(function() {return true});
                tjek++;
              }          
            }

            if(tjek == 0){
              this.typeArray.push(type);
            }
          }

          this.searchMenu = this.typeArray.toString();
          console.log(this.searchMenu);

          axios
            .get('http://localhost/re-portfolio/API/index.php/api/projekt/search-menu',{
              headers: {
                'Accept': 'application/json'
              },
              params:{
                search: this.searchMenu
              }
            })
            .then(Response => {
              // this.allProjects = Response.data
              console.log(Response.data);
              this.allProject()
              // console.log(this.allProjects)
            })
            .catch(err => {
              console.log(err.toString());
            })

        },
        test1(id, sted){
          if(sted == 'arbejdstype'){
            let countArbejdsType = this.arbejdsType.length;
            for(let i = 0; i < countArbejdsType; i++){

              if(document.getElementById('arbejdstype' + this.arbejdsType[i].id).checked == true){
                if(this.arbejdsType[i].id != id){
                  document.getElementById('arbejdstype' + this.arbejdsType[i].id).checked = false;
                  this.test('arbejds_type-' + this.arbejdsType[i].id);

                }
              }
              
            }
          }
          else if(sted == 'software'){
            let countSoftware = this.software.length;
            for(let i = 0; i < countSoftware; i++){

              if(document.getElementById('software' + this.software[i].id).checked == true){
                if(this.software[i].id != id){
                  document.getElementById('software' + this.software[i].id).checked = false;
                  this.test('software-' + this.software[i].id);
                }
              }
            }
          }
        },
        stickNavbar(){
          let projekt = document.getElementById("projekterne");

          // Bruger eventer scroll for at se hvornår man rækker sig op eller ned på siden
          if(window.scrollY > 0){
            projekt.classList.add("strickyProjektHeigth");
          }
          else{
            projekt.classList.remove("strickyProjektHeigth");
          }
        },
        imagesShiftSize(){
          let Boks1 = document.getElementById("boks1")
          let Boks2 = document.getElementById("boks2")
          let Boks3 = document.getElementById("boks3")
          let Boks4 = document.getElementById("boks4")
          let Boks5 = document.getElementById("boks5")
          let Boks6 = document.getElementById("boks6")
          let Boks7 = document.getElementById("boks7")
          let Boks8 = document.getElementById("boks8")
          let Boks9 = document.getElementById("boks9")
          let Boks10 = document.getElementById("boks10")
          let Boks11 = document.getElementById("boks11")
          let Boks12 = document.getElementById("boks12")

          let Tekst1 = document.getElementById("tekst1")
          let Tekst2 = document.getElementById("tekst2")
          let Tekst3 = document.getElementById("tekst3")
          let Tekst4 = document.getElementById("tekst4")
          let Tekst5 = document.getElementById("tekst5")
          let Tekst6 = document.getElementById("tekst6")
          let Tekst7 = document.getElementById("tekst7")
          let Tekst8 = document.getElementById("tekst8")
          let Tekst9 = document.getElementById("tekst9")
          let Tekst10 = document.getElementById("tekst10")
          let Tekst11 = document.getElementById("tekst11")
          let Tekst12 = document.getElementById("tekst12")

          let Triangle1 = document.getElementById("triangle1")
          let Triangle2 = document.getElementById("triangle2")
          let Triangle3 = document.getElementById("triangle3")
          let Triangle4 = document.getElementById("triangle4")
          let Triangle5 = document.getElementById("triangle5")
          let Triangle6 = document.getElementById("triangle6")
          let Triangle7 = document.getElementById("triangle7")
          let Triangle8 = document.getElementById("triangle8")
          let Triangle9 = document.getElementById("triangle9")
          let Triangle10 = document.getElementById("triangle10")
          let Triangle11 = document.getElementById("triangle11")
          let Triangle12 = document.getElementById("triangle12")

          if(this.windowswidth <= 769){
            console.log("tablet");
              Boks1.classList.add("boks1-100");
              Boks1.classList.remove("boks1-50");
              Boks2.classList.add("boks2-100");
              Boks2.classList.remove("boks2-50");
              Boks3.classList.add("boks3-100");
              Boks3.classList.remove("boks3-50");
              Boks4.classList.add("boks4-100");
              Boks4.classList.remove("boks4-50");
              Boks5.classList.add("boks5-100");
              Boks5.classList.remove("boks5-50");
              Boks6.classList.add("boks6-100");
              Boks6.classList.remove("boks6-50");
              Boks7.classList.add("boks7-100");
              Boks7.classList.remove("boks7-50");
              Boks8.classList.add("boks8-100");
              Boks8.classList.remove("boks8-50");
              Boks9.classList.add("boks9-100");
              Boks9.classList.remove("boks9-50");
              Boks10.classList.add("boks10-100");
              Boks10.classList.remove("boks10-50");
              Boks11.classList.add("boks11-100");
              Boks11.classList.remove("boks11-50");
              Boks12.classList.add("boks12-100");
              Boks12.classList.remove("boks12-50");

              Tekst1.classList.add("tekst1-100");
              Tekst1.classList.remove("tekst1-50");
              Tekst2.classList.add("tekst2-100");
              Tekst2.classList.remove("tekst2-50");
              Tekst3.classList.add("tekst3-100");
              Tekst3.classList.remove("tekst3-50");
              Tekst4.classList.add("tekst4-100");
              Tekst4.classList.remove("tekst4-50");
              Tekst5.classList.add("tekst5-100");
              Tekst5.classList.remove("tekst5-50");
              Tekst6.classList.add("tekst6-100");
              Tekst6.classList.remove("tekst6-50");
              Tekst7.classList.add("tekst7-100");
              Tekst7.classList.remove("tekst7-50");
              Tekst8.classList.add("tekst8-100");
              Tekst8.classList.remove("tekst8-50");
              Tekst9.classList.add("tekst9-100");
              Tekst9.classList.remove("tekst9-50");
              Tekst10.classList.add("tekst10-100");
              Tekst10classList.remove("tekst10-50");
              Tekst11.classList.add("tekst11-100");
              Tekst11.classList.remove("tekst11-50");
              Tekst12.classList.add("tekst12-100");
              Tekst12.classList.remove("tekst12-50");

              Triangle1.classList.add("triangle1-100");
              Triangle1.classList.remove("triangle1-50");
              Triangle2.classList.add("triangle2-100");
              Triangle2.classList.remove("triangle2-50");
              Triangle3.classList.add("triangle3-100");
              Triangle3.classList.remove("triangle3-50");
              Triangle4.classList.add("triangle4-100");
              Triangle4.classList.remove("triangle4-50");
              Triangle5.classList.add("triangle5-100");
              Triangle5.classList.remove("triangle5-50");
              Triangle6.classList.add("triangle6-100");
              Triangle6.classList.remove("triangle6-50");
              Triangle7.classList.add("triangle7-100");
              Triangle7.classList.remove("triangle7-50");
              Triangle8.classList.add("triangle8-100");
              Triangle8.classList.remove("triangle8-50");
              Triangle9.classList.add("triangle9-100");
              Triangle9.classList.remove("triangle9-50");
              Triangle10.classList.add("triangle10-100");
              Triangle10.classList.remove("triangle10-50");
              Triangle11.classList.add("triangle11-100");
              Triangle11.classList.remove("triangle11-50");
              Triangle12.classList.add("triangle12-100");
              Triangle12.classList.remove("triangle12-50");
          }
          else{
            console.log("computer");
            if(this.css == "display: none;"){
              Boks1.classList.add("boks1-100");
              Boks1.classList.remove("boks1-50");
              Boks2.classList.add("boks2-100");
              Boks2.classList.remove("boks2-50");
              Boks3.classList.add("boks3-100");
              Boks3.classList.remove("boks3-50");
              Boks4.classList.add("boks4-100");
              Boks4.classList.remove("boks4-50");
              Boks5.classList.add("boks5-100");
              Boks5.classList.remove("boks5-50");
              Boks6.classList.add("boks6-100");
              Boks6.classList.remove("boks6-50");
              Boks7.classList.add("boks7-100");
              Boks7.classList.remove("boks7-50");
              Boks8.classList.add("boks8-100");
              Boks8.classList.remove("boks8-50");
              Boks9.classList.add("boks9-100");
              Boks9.classList.remove("boks9-50");
              Boks10.classList.add("boks10-100");
              Boks10.classList.remove("boks10-50");
              Boks11.classList.add("boks11-100");
              Boks11.classList.remove("boks11-50");
              Boks12.classList.add("boks12-100");
              Boks12.classList.remove("boks12-50");

              Tekst1.classList.add("tekst1-100");
              Tekst1.classList.remove("tekst1-50");
              Tekst2.classList.add("tekst2-100");
              Tekst2.classList.remove("tekst2-50");
              Tekst3.classList.add("tekst3-100");
              Tekst3.classList.remove("tekst3-50");
              Tekst4.classList.add("tekst4-100");
              Tekst4.classList.remove("tekst4-50");
              Tekst5.classList.add("tekst5-100");
              Tekst5.classList.remove("tekst5-50");
              Tekst6.classList.add("tekst6-100");
              Tekst6.classList.remove("tekst6-50");
              Tekst7.classList.add("tekst7-100");
              Tekst7.classList.remove("tekst7-50");
              Tekst8.classList.add("tekst8-100");
              Tekst8.classList.remove("tekst8-50");
              Tekst9.classList.add("tekst9-100");
              Tekst9.classList.remove("tekst9-50");
              Tekst10.classList.add("tekst10-100");
              Tekst10classList.remove("tekst10-50");
              Tekst11.classList.add("tekst11-100");
              Tekst11.classList.remove("tekst11-50");
              Tekst12.classList.add("tekst12-100");
              Tekst12.classList.remove("tekst12-50");

Triangle1.classList.remove("triangle1-50");
              Triangle1.classList.add("triangle1-100");
              Triangle2.classList.remove("triangle2-50");
              Triangle2.classList.add("triangle2-100");
              Triangle3.classList.remove("triangle3-50");
              Triangle3.classList.add("triangle3-100");
              Triangle4.classList.remove("triangle4-50");
              Triangle4.classList.add("triangle4-100");
              
              // Triangle1.classList.add("triangle1-100");
              // Triangle1.classList.remove("triangle1-50");
              // Triangle2.classList.add("triangle2-100");
              // Triangle2.classList.remove("triangle2-50");
              // Triangle3.classList.add("triangle3-100");
              // Triangle3.classList.remove("triangle3-50");
              // Triangle4.classList.add("triangle4-100");
              // Triangle4.classList.remove("triangle4-50");
              // Triangle5.classList.add("triangle5-100");
              // Triangle5.classList.remove("triangle5-50");
              // Triangle6.classList.add("triangle6-100");
              // Triangle6.classList.remove("triangle6-50");
              // Triangle7.classList.add("triangle7-100");
              // Triangle7.classList.remove("triangle7-50");
              // Triangle8.classList.add("triangle8-100");
              // Triangle8.classList.remove("triangle8-50");
              // Triangle9.classList.add("triangle9-100");
              // Triangle9.classList.remove("triangle9-50");
              // Triangle10.classList.add("triangle10-100");
              // Triangle10.classList.remove("triangle10-50");
              // Triangle11.classList.add("triangle11-100");
              // Triangle11.classList.remove("triangle11-50");
              // Triangle12.classList.add("triangle12-100");
              // Triangle12.classList.remove("triangle12-50");
            }
            else{
              Boks1.classList.remove("boks1-100");
              Boks1.classList.add("boks1-50");
              Boks2.classList.remove("boks2-100");
              Boks2.classList.add("boks2-50");
              Boks3.classList.remove("boks3-100");
              Boks3.classList.add("boks3-50");
              Boks4.classList.remove("boks4-100");
              Boks4.classList.add("boks4-50");
              Boks5.classList.remove("boks5-100");
              Boks5.classList.add("boks5-50");
              Boks6.classList.remove("boks6-100");
              Boks6.classList.add("boks6-50");
              Boks7.classList.remove("boks7-100");
              Boks7.classList.add("boks7-50");
              Boks8.classList.remove("boks8-100");
              Boks8.classList.add("boks8-50");
              Boks9.classList.remove("boks9-100");
              Boks9.classList.add("boks9-50");
              Boks10.classList.remove("boks10-100");
              Boks10.classList.add("boks10-50");
              Boks11.classList.remove("boks11-100");
              Boks11.classList.add("boks11-50");
              Boks12.classList.remove("boks12-100");
              Boks12.classList.add("boks12-50");

              Tekst1.classList.remove("tekst1-100");
              Tekst1.classList.add("tekst1-50");
              Tekst2.classList.remove("tekst2-100");
              Tekst2.classList.add("tekst2-50");
              Tekst3.classList.remove("tekst3-100");
              Tekst3.classList.add("tekst3-50");
              Tekst4.classList.remove("tekst4-100");
              Tekst4.classList.add("tekst4-50");
              Tekst5.classList.remove("tekst5-100");
              Tekst5.classList.add("tekst5-50");
              Tekst6.classList.remove("tekst6-100");
              Tekst6.classList.add("tekst6-50");
              Tekst7.classList.remove("tekst7-100");
              Tekst7.classList.add("tekst7-50");
              Tekst8.classList.remove("tekst8-100");
              Tekst8.classList.add("tekst8-50");
              Tekst9.classList.remove("tekst9-100");
              Tekst9.classList.add("tekst9-50");
              Tekst10.classList.remove("tekst10-100");
              Tekst10.classList.add("tekst10-50");
              Tekst11.classList.remove("tekst11-100");
              Tekst11.classList.add("tekst11-50");
              Tekst12.classList.remove("tekst12-100");
              Tekst12.classList.add("tekst12-50");

              Triangle1.classList.remove("triangle1-100");
              Triangle1.classList.add("triangle1-50");
              Triangle2.classList.remove("triangle2-100");
              Triangle2.classList.add("triangle2-50");
              Triangle3.classList.remove("triangle3-100");
              Triangle3.classList.add("triangle3-50");
              Triangle4.classList.remove("triangle4-100");
              Triangle4.classList.add("triangle4-50");
              Triangle5.classList.remove("triangle5-100");
              Triangle5.classList.add("triangle5-50");
              Triangle6.classList.remove("triangle6-100");
              Triangle6.classList.add("triangle6-50");
              Triangle7.classList.remove("triangle7-100");
              Triangle7.classList.add("triangle7-50");
              Triangle8.classList.remove("triangle8-100");
              Triangle8.classList.add("triangle8-50");
              Triangle9.classList.remove("triangle9-100");
              Triangle9.classList.add("triangle9-50");
              Triangle10.classList.remove("triangle10-100");
              Triangle10.classList.add("triangle10-50");
              Triangle11.classList.remove("triangle11-100");
              Triangle11.classList.add("triangle11-50");
              Triangle12.classList.remove("triangle12-100");
              Triangle12.classList.add("triangle12-50");
            }
          }
        },
        getWindowWidth(event) {
          this.windowswidth = window.innerWidth;
          this.imagesShiftSize()
        },
        getClass(index){
          if(index === 0){
            return 'boks1-100'
          }
          else if(index === 1){
            return 'boks2-100'
          }
          else if(index === 2){
            return 'boks3-100'
          }
          else if(index === 3){
            return 'boks4-100'
          }
          else if(index === 4){
            return 'boks5-100'
          }
          else if(index === 5){
            return 'boks6-100'
          }
          else if(index === 6){
            return 'boks7-100'
          }
          else if(index == 7){
            return 'boks8-100'
          }
          else if(index === 8){
            return 'boks9-100'
          }
          else if(index === 9){
            return 'boks10-100'
          }
          else if(index === 10){
            return 'boks11-100'
          }
          else if(index === 11){
            return 'boks12-100'
          }
        },
        getId(index){
          if(index === 0){
            return 'boks1'
          }
          else if(index === 1){
            return 'boks2'
          }
          else if(index === 2){
            return 'boks3'
          }
          else if(index === 3){
            return 'boks4'
          }
          else if(index === 4){
            return 'boks5'
          }
          else if(index === 5){
            return 'boks6'
          }
          else if(index === 6){
            return 'boks7'
          }
          else if(index == 7){
            return 'boks8'
          }
          else if(index === 8){
            return 'boks9'
          }
          else if(index === 9){
            return 'boks10'
          }
          else if(index === 10){
            return 'boks11'
          }
          else if(index === 11){
            return 'boks12'
          }
        }
      },
      beforeDestroy() {
      window.removeEventListener('resize', this.getWindowWidth);
      window.removeEventListener('scroll', this.stickNavbar)
    }
  }
</script>

<!-- almindelig css -->
<style>
  .strickyProjektHeigth{
    padding-top: 4.8em;
  }

  .imagesSize{
    width: 100%;
    height: 100%;
    border: 1px solid #607272;
  }

  .overksriftFlexBoks{
    display: flex;
    flex-flow: row nowrap;
    margin: 0.5em;
  }

  .overskriftSize{
    font-size: 4em;
  }

  /*************************************************/
  /*                   side menu                   */
  /*************************************************/
  .hideAndSeekBoks{
    display: flex;
    flex-flow: column wrap;
    background-color: #CCFFFF;
    width: 100%;
    margin: -0.2em 0 0.1em 0;
  }

  .hideAndSeekButtom{
    border: none;
    background-color: #B8E6E6;
    padding: 0.5em;
    margin: 0.1em 0;
    width: 100%;
    text-align: start;
    font-size: 1.5em;
    outline: none;
  }

  /*************************************************/
  /*                 Projekterne                   */
  /*************************************************/
  .OuterBoks{
    display: flex;
  }

  /*************************************************/
  /*            billederne og teksten              */
  /*************************************************/
  .boks1-100{
    background: chartreuse;
    width: 22em;
    height: 19em;
    margin: 2em 2em 2em 5em;
  }

  .boks1-50{
    background: chartreuse;
    width: 16.2em;
    height: 13.5em;
    margin: 0.2em 2em 2em 5em;
  }

  .boks2-100{
    background: cyan;
    width: 22em;
    height: 19em;
    margin: 2em 2em 2em 2em; 
  }

  .boks2-50{
    background: cyan;
    width: 16.2em;
    height: 13.5em;
    margin: 0.2em 2em 2em 2em;
  }

  .boks3-100{
    background: darkorange;
    width: 22em;
    height: 42em;
    margin: 2em 5em 2em 2em;
  }

  .boks3-50{
    background: darkorange;
    width: 15.9em;
    height: 31em;
    margin: 0.2em 5em 2em 2em;
  }

  .boks4-100{
    background: deeppink;
    width: 48em;
    height: 19em;
    margin: 25em 3em 2em -79em;
  }

  .boks4-50{
    background: deeppink;
    width: 36.1em;
    height: 13.6em;
    margin: 17.5em 4em 2em -61.4em;
  }

  .boks5-100{
    background-color: crimson;
    width: 22em;
    height: 19em;
    margin: 2em 2.0em 2.0em 5em;
  }

  .boks5-50{
    background-color: crimson;
    width: 16.2em;
    height: 13.5em;
    margin: 2em 2.0em 2.0em 5em;
  }

  .boks6-100{
    background-color: darkblue;
    width: 48em;
    height: 19em;
    margin: 2em 5em 2em 2em;
  }

  .boks6-50{
    background-color: darkblue;
    width: 36.1em;
    height: 13.6em;
    margin: 2em 5em 2em 2em;
  }

  .boks7-100{
    background-color: darkorchid;
    width: 48em;
    height: 19em;
    margin: 2em 2em 2em 5em;
  }

  .boks7-50{
    background-color: darkorchid;
    width: 36.1em;
    height: 13.6em;
    margin: 2em 2em 2em 5em;
  }

  .boks8-100{
    background-color: dodgerblue;
    width: 22em;
    height: 19em;
    margin: 2em 5em 2em 2em;
  }

  .boks8-50{
    background-color: dodgerblue;
    width: 16.2em;
    height: 13.5em;
    margin: 2em 5em 2em 2em;
  }

  .boks9-100{
    background-color: fuchsia;
    width: 22em;
    height: 42em;
    margin: 2em 2em 2em 5em;
  }

  .boks9-50{
    background-color: fuchsia;
    width: 15.9em;
    height: 31em;
    margin: 2em 2em 2em 5em;
  }

  .boks10-100{
    background-color: gold;
    width: 22em;
    height: 19em;
    margin: 2em;
  }

  .boks10-50{
    background-color: gold;
    width: 16.2em;
    height: 13.5em;
    margin: 2em;
  }

  .boks11-100{
    background-color: gray;
    width: 22em;
    height: 19em;
    margin: 2em 5em 2em 2em;
  }

  .boks11-50{
    background-color: gray;
    width: 16.2em;
    height: 13.5em;
    margin: 2em 5em 2em 2em;
  }

  .boks12-100{
    background-color: greenyellow;
    width: 48em;
    height: 19em;
    margin: -21em 2em 2em 31em;
  }

  .boks12-50{
    background-color: greenyellow;
    width: 36.1em;
    height: 13.6em;
    margin: -15.5em 2em 2em 24.9em;
  }

  .OuterBoksFlex{
    display: flex;
    flex-flow: row wrap;
  }

  .tekst1-100, .tekst2-100, .tekst5-100, .tekst8-100, .tekst10-100, .tekst11-100{
    font-size: 1.5em;
    padding: 0.5em;
    position: absolute;
    background: #CCFFFF;
    width: 14.6em;
    text-align: center;
    margin: 9.5em 0 0 -0.9em;
  }

  .tekst1-50, .tekst2-50, .tekst5-50, .tekst8-50, .tekst10-50, .tekst11-50{
    font-size: 1.0em;
    padding: 0.5em;
    position: absolute;
    background: #CCFFFF;
    width: 16.1em;
    text-align: center;
    margin: 9.5em 0 0 -0.9em;
  }
 
  .tekst3-100, .tekst9-100{
    font-size: 1.5em;
    padding: 0.5em;
    position: absolute;
    background: #CCFFFF;
    width: 14.6em;
    text-align: center;
    margin: 24.9em 0 0 -0.9em;
  }

  .tekst3-50, .tekst9-50{
    font-size: 1em;
    padding: 0.5em;
    position: absolute;
    background: #CCFFFF;
    width: 15.8em;
    text-align: center;
    margin: 26.8em 0 0 -0.9em;
  }

  .tekst4-100, .tekst6-100, .tekst7-100, .tekst12-100{
    font-size: 1.5em;
    padding: 0.5em;
    position: absolute;
    background: #CCFFFF;
    width: 31.9em;
    text-align: center;
    margin: 9.5em 0 0 -0.9em;
  }

  .tekst4-50, .tekst6-50, .tekst7-50, .tekst12-50{
    font-size: 1em;
    padding: 0.5em;
    position: absolute;
    background: #CCFFFF;
    width: 36em;
    text-align: center;
    margin: 9.5em 0 0 -0.9em;
  }


  .triangle1-100, .triangle2-100, .triangle5-100, .triangle8-100, .triangle10-100, .triangle11-100{
    border-top: 13px solid #A3CCCC;
    border-left: 22px solid transparent;
    position: absolute;
    margin: 276px 0em 0 -1.4em;
  }

  .triangle1-50, .triangle2-50, .triangle5-50, .triangle8-50, .triangle10-50, .triangle11-50{
    border-top: 9px solid #A3CCCC;
    border-left: 15px solid transparent;
    position: absolute;
    margin: 184px 0 0 -15px;
  }

  .triangle3-100, .triangle9-100{
    border-top: 13px solid #A3CCCC;
    border-left: 22px solid transparent;
    position: absolute;
    margin: 645px 0em 0 -1.4em;
  }

  .triangle3-50, .triangle9-50{
    border-top: 9px solid #A3CCCC;
    border-left: 15px solid transparent;
    position: absolute;
    margin: 461px 0 0 -15px;
  }

  .triangle4-100, .triangle6-100, .triangle7-100, .triangle12-100{
    border-top: 13px solid #A3CCCC;
    border-left: 22px solid transparent;
    position: absolute;
        margin: 276px 0em 0 -1.4em;
  }

  .triangle4-50, .triangle6-50, .triangle7-50, .triangle12-50{
    border-top: 9px solid #A3CCCC;
    border-left: 15px solid transparent;
    position: absolute;
    position: absolute;
    margin: 184px 0 0 -15px;
  }
</style>

<!-- media querys -->
<style>
  @media screen and (max-width: 1366px){
    .boks4-50 {
      margin: 17.5em 4.5em 2em -61.4em;
    }
    .boks4-100{
      margin: 25em 4em 2em -79em;
    }
  }

  @media screen and (max-width: 1340px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 21em;
      height: 18em;
    }

    .boks3-100, .boks9-100{
      width: 21em;
      height: 40em;
    }

    .boks4-100, .boks6-100, .boks7-100{
      width: 46em;
      height: 18em;
    }

    .boks4-100{
      margin: 24em 7em 2em -76em;
    }

    .boks12-100{
      width: 46em;
      height: 18em;
      margin: -20em 2em 2em 30em;
    }

    .tekst1-100{
      width: 13.9em;
      margin: 8.5em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 13.9em;
      margin: 23.2em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 30.6em;
      margin: 8.5em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 252px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 605px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 252px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 1325px){
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 16em;
      height: 13em;
    }

    .boks3-50, .boks9-50{
      width: 16em;
      height: 30em;
    }

    .boks4-50, .boks6-50, .boks7-50{
      width: 36em;
      height: 13.2em;
    }

    .boks4-50{
      margin: 17em 9em 2em -61em;
    }

    .boks12-50{
      width: 36em;
      height: 13em;
      margin: -15em 2em 2em 25em;
    }

    .tekst1-50{
      width: 15.9em;
    }

    .tekst2-50{
      width: 15.9em;
    }

    .tekst3-50{
      width: 35.9em;
    }
  }

  @media screen and (max-width: 1319px){
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 15.5em;
      height: 12.5em;
    }

    .boks3-50, .boks9-50{
      width: 15.5em;
      height: 29.5em;
    }

    .boks4-50, .boks6-50, .boks7-50{
      width: 35em;
      height: 12.7em;
    }

    .boks4-50{
      margin: 17em 11em 2em -59.5em;
    }

    .boks12-50{
      width: 35em;
      height: 13em;
      margin: -15em 2em 2em 24.5em;
    }

    .tekst1-50{
      width: 15.4em;
      margin: 9em 0 0 -0.9em;
    }

    .tekst2-50{
      width: 15.4em;
      margin: 25.8em 0 0 -0.9em;
    }

    .tekst3-50{
      width: 35em;
      margin: 9em 0 0 -0.9em;
    }

    .triangle1-50{
      margin: 176px 0 0 -15px;
    }

    .triangle2-50{
     margin: 445px 0 0 -15px;
    }

    .triangle3-50{
      margin: 176px 0 0 -15px;
    }
  }

  @media screen and (max-width: 1290px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 20em;
      height: 17em;
    }

    .boks3-100, .boks9-100{
      width: 20em;
      height: 38em;
    }

    .boks4-100, .boks6-100, .boks7-100{
      width: 44em;
      height: 17em;
    }

    .boks4-100{
      margin: 23em 7em 2em -73em;
    }

    .boks12-100{
      width: 44em;
      height: 17em;
      margin: -19em 2em 2em 29em;
    }

    .tekst1-100{
      width: 318px;
      margin: 8em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 318px;
      margin: 22em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 702px;
      margin: 8em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 240px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 576px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 240px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 1289px){
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 14.5em;
      height: 11.5em;
    }

    .boks3-50, .boks9-50{
      width: 14.5em;
      height: 27.5em;
    }

    .boks4-50, .boks6-50, .boks7-50{
      width: 33em;
      height: 11.7em;
    }

    .boks4-50{
      margin: 16em 11em 2em -56.5em;
    }

    .boks12-50{
      width: 33em;
      height: 12em;
      margin: -14em 2em 2em 23.5em;
    }

    .tekst1-50{
      width: 14.4em;
          margin: 8em 0 0 -0.9em;
    }

    .tekst2-50{
      width: 14.4em;
      margin: 23.8em 0 0 -0.9em;
    }

    .tekst3-50{
      width: 33em;
      margin: 8em 0 0 -0.9em;
    }

    .triangle1-50 {
      margin: 160px 0 0 -15px;
    }

    .triangle2-50 {
      margin: 413px 0 0 -15px;
    }

    .triangle3-50 {
      margin: 160px 0 0 -15px;
    }
  }

  @media screen and (max-width: 1247px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 19em;
      height: 16em;
    }

    .boks3-100, .boks9-100{
      width: 19em;
      height: 36em;
    }

    .boks4-100, .boks6-100, .boks7-100{
      width: 42em;
      height: 16em;
    }

    .boks4-100{
      margin: 22em 7em 2em -70em;
    }

    .boks12-100{
      width: 42em;
      height: 16em;
      margin: -18em 2em 2em 28em;
    }

    .tekst1-100{
      width: 302px;
      margin: 7em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 302px;
      margin: 20.4em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 671px;
      margin: 7em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 216px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 537px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 216px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 1229px){
    .boks1-50{
      margin: 0.2em 1.5em 1.5em 4.5em;
    }

    .boks2-50{
      margin: 0.2em 1.5em 1.5em 1.5em;
    }

    .boks5-50{
      margin: 1.5em 1.5em 1.5em 4.5em;
    }

    .boks8-50{
      margin: 1.5em 4.5em 1.5em 1.5em;
    }

    .boks10-50{
      margin: 1.5em 1.5em 1.5em 1.5em;
    }
    
    .boks11-50{
      margin: 1.5em 4.5em 1.5em 1.5em;
    }

    .boks9-50{
      height: 26.5em;
      margin: 1.5em 1.5em 1.5em 4.5em;
    }

    .boks3-50{
      height: 26.5em;
      margin: 0.2em 4.5em 1.5em 1.5em;
    }

    .boks4-50{
      width: 32em;
      margin: 15em 11em 2em -54em;
    }

    .boks6-50{
      width: 32em;
      margin: 1.5em 4.5em 1.5em 1.5em;
    }

    .boks7-50{
      width: 32em;
      margin: 1.5em 1.5em 1.5em 4.5em;
    }

    .boks12-50{
      width: 32em;
      height: 12em;
      margin: -13.5em 2em 2em 22em;
    }

    .tekst3-50{
      width: 32em;
    }

    .tekst2-50 {
      margin: 22.8em 0 0 -0.9em;
    }

    .triangle2-50 {
      margin: 397px 0 0 -15px;
    }
  }

  @media screen and (max-width: 1199px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 18em;
      height: 15em;
    }

    .boks3-100, .boks9-100{
      width: 18em;
      height: 34em;
    }

    .boks4-100, .boks6-100, .boks7-100{
      width: 40em;
      height: 15em;
    }

    .boks4-100{
      margin: 21em 7em 2em -67em;
    }

    .boks12-100{
      width: 40em;
      height: 15em;
      margin: -17em 2em 2em 27em;
    }

    .tekst1-100{
      width: 286px;
      margin: 6.8em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 286px;
      margin: 19.5em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 639px;
      margin: 6.8em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 211px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 516px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 211px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 1169px){
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 13.5em;
      height: 11em;
    }

    .boks3-50, .boks9-50{
      width: 13.5em;
      height: 25em;
    }

    .boks4-50, .boks6-50, .boks7-50, .boks12-50{
      width: 30em;
      height: 11em;
    }

    .boks4-50{
      margin: 14em 11em 2em -51em;
    }

    .boks12-50{
      margin: -12.5em 2em 2em 21em;
    }

    .tekst1-50 {
      width: 13.4em;
      margin: 7.5em 0 0 -0.9em;
    }

    .tekst2-50 {
      width: 13.4em;
      margin: 21.3em 0 0 -0.9em;
    }

    .tekst3-50 {
      width: 30em;
      margin: 7.5em 0 0 -0.9em;
    }

    .triangle1-50 {
      margin: 152px 0 0 -15px;
    }

    .triangle2-50 {
      margin: 373px 0 0 -15px;
    }
    
    .triangle3-50 {
      margin: 152px 0 0 -15px;
    }
  }

  @media screen and (max-width: 1151px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 17em;
      height: 15em;
    }

    .boks3-100, .boks9-100{
      width: 17em;
      height: 34em;
    }

    .boks4-100, .boks6-100, .boks7-100{
      width: 38em;
      height: 15em;
    }

    .boks4-100{
      margin: 21em 7em 2em -64em;
    }

    .boks12-100{
      width: 38em;
      height: 15em;
      margin: -17em 2em 2em 26em;
    }

    .tekst1-100{
      width: 270px;
      margin: 6.8em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 270px;
      margin: 19.5em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 606px;
      margin: 6.8em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 211px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 516px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 211px 0em 0 -1.4em;
    }
  }

  @media  screen and (max-width: 1120px){
    .tekst3-50 {
      width: 29.9em;
      margin: 7.5em 0 0 -0.9em;
    }
  }

  @media screen and (max-width: 1109px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 16em;
      height: 14em;
    }

    .boks1-50 {
      margin: 0.2em 1em 1em 4em;
    }

    .boks2-50 {
      margin: 0.2em 1em 1em 1em;
    }

    .boks5-50 {
      margin: 1em 1em 1em 4em;
    }

    .boks8-50 {
      margin: 1em 4em 1em 1em;
    }

    .boks10-50 {
      margin: 1em 1em 1em 1em;
    }

    .boks11-50 {
      margin: 1em 4em 1em 1em;
    }

    .boks3-100, .boks9-100{
      width: 16em;
      height: 32em;
    }

    .boks3-50 {
      margin: 0.2em 4em 1em 1em;
      height: 24em;
    }

    .boks9-50 {
      height: 24em;
      margin: 1em 1em 1em 4em;
    }

    .boks4-100, .boks6-100, .boks7-100, .boks12-100{
      width: 36em;
      height: 14em;
    }

    .boks4-50, .boks6-50, .boks7-50 {
      width: 29em;
    }

    .boks6-50 {
      margin: 1em 4em 1em 1em;
    }

    .boks7-50 {
      margin: 1em 1em 1em 4em;
    }

    .boks4-100{
      margin: 20em 7em 2em -61em;
    }

    .boks4-50 {
      width: 29em;
      margin: 13em 11em 1em -48.5em;
    }

    .boks12-100{
      margin: -16em 2em 2em 25em;
    }

    .boks12-50 {
      width: 29em;
      margin: -12em 2em 2em 19.5em;
    }

    .tekst1-100{
      width: 254px;
      margin: 6em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 254px;
      margin: 18.1em 0 0 -0.9em;
    }

    .tekst2-50 {
      width: 13.4em;
      margin: 20.3em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 574px;
      margin: 6em 0 0 -0.9em;
    }

    .tekst3-50 {
      width: 28.9em;
      margin: 7.5em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 192px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 482px 0em 0 -1.4em;
    }

    .triangle2-50 {
      margin: 357px 0 0 -15px;
    }

    .triangle3-100{
      margin: 192px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 1055px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 15em;
      height: 13em;
    }

    .boks3-100, .boks9-100{
      width: 15em;
      height: 30em;
    }

    .boks4-100, .boks6-100, .boks7-100, .boks12-100{
      width: 34em;
      height: 13em;
    }

    .boks4-100{
      margin: 19em 7em 2em -58em;
    }

    .boks12-100{
      margin: -15em 2em 2em 24em;
    }

    .tekst1-100{
      width: 239px;
      margin: 5.5em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 239px;
      margin: 16.9em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 542px;
      margin: 5.5em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 180px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 453px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 180px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 1049px){
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 12.5em;
      height: 11em;
    }

    .boks3-50, .boks9-50{
      width: 12.5em;
      height: 24em;
    }

    .boks4-50, .boks6-50, .boks7-50, .boks12-50{
      width: 27em;
      height: 11em;
    }

    .boks4-50{
      margin: 13.2em 11em 1em -45.5em;
    }

    .boks12-50{
      margin: -12em 2em 2em 18.5em;
    }

    .tekst1-50 {
      width: 12.4em;
    }

    .tekst2-50 {
      width: 12.4em;
      margin: 20.5em 0 0 -0.9em;
    }

    .tekst3-50 {
      width: 26.9em;
    }

    .triangle2-50 {
      margin: 360px 0 0 -15px;
    }
  }

  @media screen and (max-width: 1008px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 14em;
      height: 12em;
    }

    .boks3-100, .boks9-100{
      width: 14em;
      height: 28em;
    }

    .boks4-100, .boks6-100, .boks7-100, .boks12-100{
      width: 32em;
      height: 12em;
    }

    .boks4-100{
      margin: 18em 7em 2em -55em;
    }

    .boks12-100{
      margin: -14em 2em 2em 23em
    }

    .tekst1-100{
      width: 222px;
      margin: 5em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 222px;
      margin: 15.7em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 510px;
      margin: 5em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 168px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 425px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 168px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 989px){
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 12em;
      height: 10em;
    }

    .boks3-50, .boks9-50{
      width: 12em;
      height: 22em;
    }

    .boks4-50, .boks6-50, .boks7-50, .boks12-50{
      width: 26em;
      height: 10em;
    }

    .boks4-50{
      margin: 12.2em 11em 1em -44em;
    }

    .boks12-50{
      margin: -11em 2em 2em 18em;
    }

    .tekst1-50 {
      width: 11.9em;
      margin: 7em 0 0 -0.9em;
    }

    .tekst2-50 {
      width: 12em;
      margin: 19em 0 0 -0.9em;
    }

    .tekst3-50 {
      width: 25.9em;
      margin: 7em 0 0 -0.9em;
    }

    .triangle1-50 {
      margin: 144px 0 0 -15px;
    }

    .triangle2-50 {
      margin: 336px 0 0 -15px;
    }

    .triangle3-50 {
      margin: 144px 0 0 -15px;
    }
  }

  @media screen and (max-width: 959px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 13em;
      height: 11em;
    }

    .boks1-50 {
      margin: 0.2em 1em 1em 3.5em;
    }

    .boks5-50 {
      margin: 1em 1em 1em 3.5em;
    }

    .boks8-50 {
      margin: 1em 3.5em 1em 1em;
    }

    .boks10-50 {
      margin: 1em;
    }

    .boks11-50 {
      margin: 1em 3.5em 1em 1em;
    }

    .boks3-100, .boks9-100{
      width: 13em;
      height: 25.5em;
    }

    .boks3-50 {
      margin: 0.2em 3.5em 1em 1em;
    }

    .boks9-50 {
     margin: 1em 1em 1em 3.5em;
    }

    .boks4-100, .boks6-100, .boks7-100, .boks12-100{
      width: 30em;
      height: 11em;
    }

    .boks4-50, .boks6-50, .boks7-50, .boks12-50 {
      width: 26em;
      height: 10em;
    }

    .boks6-50 {
      margin: 1em 3.5em 1em 1em;
    }

    .boks7-50 {
      margin: 1em 1em 1em 3.5em;
    }

    .boks4-100{
      margin: 16.5em 7em 2em -52em;
    }

    .boks4-50 {
      margin: 12.2em 11em 1em -43.5em;
    }

    .boks12-100{
      margin: -13em 2em 2em 22em;
    }

    .boks12-50 {
      margin: -11em 2em 2em 17.6em;
    }

    .tekst1-100{
      width: 206px;
      margin: 4.3em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 206px;
      margin: 14em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 479px;
      margin: 4.3em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 151px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 384px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 151px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 939px){
    .hideAndSeekButtom {
      font-size: 1.4em;
    }
    
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 11em;
      height: 9em;
    }

    .boks3-50, .boks9-50{
      width: 11em;
      height: 20em;
    }

    .boks4-50, .boks6-50, .boks7-50, .boks12-50{
      width: 24em;
      height: 9em;
    }

    .boks4-50{
      margin: 11.2em 11em 1em -40.5em;
    }

    .boks12-50{
      margin: -10em 2em 2em 16.5em;
    }

    .tekst1-50 {
      width: 10.9em;
      margin: 6em 0 0 -0.9em;
    }

    .tekst2-50 {
      width: 11em;
      margin: 17em 0 0 -0.9em;
    }

    .tekst3-50 {
      width: 23.9em;
      margin: 6em 0 0 -0.9em;
    }

    .triangle1-50 {
      margin: 128px 0 0 -15px;
    }

    .triangle2-50 {
      margin: 304px 0 0 -15px;
    }

    .triangle3-50 {
      margin: 128px 0 0 -15px;
    }
  }

  @media screen and (max-width: 911px){
    .boks1-100 {
      margin: 2em 1em 1em 6em;
    }

    .boks2-100 {
      margin: 2em 1em 1em 1em;
    }

    .boks3-100 {
      height: 24em;
      margin: 2em 4em 1em 1em;
    }

    .boks4-100 {
      width: 28em;
      margin: 15em 7em 1em -47em;
    }

    .boks5-100 {
      margin: 1em 1em 1em 6em;
    }

    .boks6-100 {
      width: 28em;
      margin: 1em 4em 1em 1em;
    }

    .boks7-100 {
      width: 28em;
      margin: 1em 1em 1em 6em;
    }

    .boks8-100 {
      margin: 1em 4em 1em 1em;
    }

    .boks9-100 {
      height: 24em;
      margin: 1em 1em 1em 6em;
    }

    .boks10-100{
      margin: 1em;
    }

    .boks11-100 {
      margin: 1em 4em 1em 1em;
    }

    .boks12-100 {
      width: 28em;
      margin: -12em 2em 2em 21em;
    }

    .tekst2-100 {
      width: 206px;
      margin: 13em 0 0 -0.9em;
    }

    .tekst3-100 {
      width: 447px;
      margin: 4.3em 0 0 -0.9em;
    }

    .triangle2-100 {
      margin: 360px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 879px){
    .hideAndSeekButtom {
      font-size: 1.3em;
    }
    
    .boks1-50, .boks2-50, .boks5-50, .boks8-50, .boks10-50, .boks11-50{
      width: 10em;
      height: 8em;
    }

    .boks3-50, .boks9-50{
      width: 10em;
      height: 18em;
    }

    .boks4-50, .boks6-50, .boks7-50, .boks12-50{
      width: 22em;
      height: 8em;
    }

    .boks4-50{
      margin: 10.2em 11em 1em -37.5em;
    }

    .boks12-50{
      margin: -9em 2em 2em 15.5em;
    }

    .tekst1-50 {
      width: 9.9em;
      margin: 5em 0 0 -0.9em;
    }

    .tekst2-50 {
      width: 9.9em;
      margin: 15em 0 0 -0.9em;
    }

    .tekst3-50 {
      width: 21.9em;
      margin: 5em 0 0 -0.9em;
    }

    .triangle1-50 {
      margin: 112px 0 0 -15px;
    }

    .triangle2-50 {
      margin: 272px 0 0 -15px;
    }

    .triangle3-50 {
      margin: 112px 0 0 -15px;
    }
  }

  @media screen and (max-width: 847px){
    .boks1-100, .boks2-100, .boks5-100, .boks8-100, .boks10-100, .boks11-100{
      width: 12em;
      height: 10em;
    }

    .boks3-100, .boks9-100{
      width: 12em;
      height: 22em;
    }

    .boks4-100, .boks6-100, .boks7-100, .boks12-100{
      width: 26em;
      height: 10em;
    }

    .boks4-100{
      margin: 14em 7em 1em -44em;
    }

    .boks12-100{
      margin: -11em 2em 2em 20em
    }

    .tekst1-100{
      width: 190px;
      margin: 3.7em 0 0 -0.9em;
    }

    .tekst2-100{
      width: 190px;
      margin: 11.7em 0 0 -0.9em;
    }

    .tekst3-100{
      width: 414px;
      margin: 3.7em 0 0 -0.9em;
    }

    .triangle1-100{
      margin: 137px 0em 0 -1.4em;
    }

    .triangle2-100{
      margin: 329px 0em 0 -1.4em;
    }

    .triangle3-100{
      margin: 137px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 819px){
    .boks1-50 {
      margin: 0.2em 1em 1em 3em;
    }

    .boks3-50 {
      margin: 0.2em 3em 1em 1em;
    }

    .boks4-50 {
      margin: 10.2em 11em 1em -37em;
    }

    .boks5-50 {
      margin: 1em 1em 1em 3em;
    }

    .boks7-50, .boks9-50 {
      margin: 1em 1em 1em 3em;
    }

    .boks8-50, .boks11-50, .boks6-50 {
      margin: 1em 3em 1em 1em;
    }

    .boks12-50 {
      margin: -9em 2em 2em 15em;
    }
  }

  @media screen and (max-width: 799px){
    .boks1-100 {
      margin: 2em 1em 1em 5em;
    }

    .boks1-50 {
      margin: 0.2em 1em 1em 2.5em;
    }

    .boks3-50 {
      margin: 0.2em 2.5em 1em 1em;
    }

    .boks4-50 {
      margin: 10.2em 11em 1em -36.5em;
    }

    .boks5-100, .boks7-100, .boks9-100{
      margin: 1em 1em 1em 5em;
    }

    .boks5-50, .boks7-50, .boks9-50 {
      margin: 1em 1em 1em 2.5em;
    }

    .boks6-100 {
      width: 26em;
      margin: 1em 4em 1em 1em;
    }

    .boks6-50, .boks8-50, .boks11-50 {
      margin: 1em 2.5em 1em 1em;
    }

    .boks12-100 {
      margin: -11em 2em 2em 19em;
    }

    .boks12-50 {
      margin: -9em 2em 2em 14.5em;
    }
  }

  @media screen and (max-width: 783px){
    .boks1-100 {
      margin: 2em 1em 1em 4em;
    }

    .boks5-100, .boks7-100, .boks9-100{
      margin: 1em 1em 1em 4em;
    }

    .boks6-100 {
      width: 26em;
      margin: 1em 4em 1em 1em;
    }

    .boks12-100 {
      margin: -11em 2em 2em 18em;
    }
  }

  @media screen and (max-width: 774px){
    .triangle1-100 {
      margin: 136px 0em 0 -1.4em;
    }

    .triangle2-100 {
      margin: 328px 0em 0 -1.4em;
    }
  }

  @media screen and (max-width: 779px){
    .boks1-50 {
      margin: 0.2em 0.5em 0.5em 2em;
    }

    .boks2-50 {
      margin: 0.2em 0.5em 0.5em 0.5em;
    }

    .boks3-50 {
      height: 17em;
      margin: 0.2em 2em 0.5em 0.5em;
    }

    .boks4-50 {
      width: 21em;
      margin: 9.2em 11em 0.5em -34em;
    }

    .boks5-50, .boks7-50, .boks9-50 {
      margin: 0.5em 0.5em 0.5em 2em;
    }

    .boks7-50{
      width: 21em;
    }

    .boks9-50{
      height: 17em;
    }

    .boks6-50{
      width: 21em;
      margin: 0.5em 2em 0.5em 0.5em;
    }

    .boks8-50{
      margin: 0.5em 2em 0.5em 0.5em;
    }

    .boks10-50 {
      margin: 0.5em;
    }

    .boks11-50 {
      margin: 0.5em 2em 0.5em 0.5em;
    }

    .boks12-50 {
      width: 21em;
      margin: -8.5em 2em 2em 13em;
    }

    .tekst1-50 {
      width: 9.5em;
      margin: 5em 0 0 -0.5em;
    }

    .tekst2-50 {
      width: 9.5em;
      margin: 14em 0 0 -0.5em;
    }

    .tekst3-50 {
      width: 20.5em;
      margin: 5em 0 0 -0.5em;
    }

    .triangle1-50 {
      border-top: 5px solid #A3CCCC;
      border-left: 9px solid transparent;
      margin: 112px 0 0 -9px;
    }

    .triangle3-50 {
      border-top: 5px solid #A3CCCC;
      border-left: 9px solid transparent;
      margin: 112px 0 0 -9px;
    }

    .triangle2-50 {
      border-top: 5px solid #A3CCCC;
      border-left: 9px solid transparent;
    margin: 256px 0 0 -9px;
}
  }

  /* tablets */
  @media screen and (max-width: 769px){
    .OuterBoks {
      display: block;
    }

    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 16em;
      height: 14em;
    }

    .boks1-100 {
      margin: 2em 2.5em 2.5em 5em;
    }

    .boks2-100{
      margin: 2em 5em 2.5em 2.5em;
    }

    .boks3-100, .boks7-100{
      width: 37em;
      height: 14em;
      margin: 2.5em 5em 2.5em 5em;
    }

    .boks4-100, .boks11-100{
      width: 16em;
      height: 33em;
      
    } 

    .boks4-100, .boks8-100, .boks10-100{
      margin: 2.5em 2.5em 2.5em 5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 2.5em 5em 2.5em 2.5em;
    }

    .boks6-100{
      margin: -16.5em 5em 2.5em 26em;
    }

    .boks12-100 {
      margin: -16.5em 2.5em 2.5em 5em;
    }

    .tekst1-100 {
      width: 254px;
      margin: 5.7em 0 0 -0.9em;
    }


    .triangle1-100 {
      margin: 185px 0em 0 -1.4em;
    }

    
  }

  @media screen and (max-width: 751px){
    .boks1-100 {
      margin: 2em 2em 2em 5em;
    }

    .boks2-100{
      margin: 2em 5em 2em 2em;
    }

    .boks3-100, .boks7-100{
      margin: 2em 5em 2em 5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 2em 2em 2em 5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 2em 5em 2em 2em;
    }

    .boks6-100{
      margin: -16em 5em 2em 25em;
    }

    .boks12-100 {
      margin: -16em 2.5em 2.5em 5em
    }
  }

  @media screen and (max-width: 735px){
    .boks1-100 {
      margin: 2em 2em 2em 4.5em;
    }

    .boks2-100{
      margin: 2em 4.5em 2em 2em;
    }

    .boks3-100, .boks7-100{
      width: 36em;
      margin: 2em 4.5em 2em 4.5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 2em 2em 2em 4.5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 2em 4.5em 2em 2em;
    }

    .boks6-100{
      margin: -16em 4.5em 2em 24.5em;
    }

    .boks12-100 {
      margin: -16em 4.5em 2em 4.5em;
    }
  }

  @media screen and (max-width: 719px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 15em;
      height: 13em;
    }

    .boks3-100, .boks7-100{
      width: 34em;
      height: 13em;
    }

    .boks4-100, .boks11-100{
      width: 15em;
      height: 30em;
    } 

    .boks6-100{
      margin: -15em 4.5em 2em 23.5em;
    }

    .boks12-100 {
      margin: -15em 4.5em 2em 4.5em;
    }
  }

  @media screen and (max-width: 687px){
    .boks1-100 {
      margin: 2em 1.5em 1.5em 4.5em;
    }

    .boks2-100{
      margin: 2em 4.5em 1.5em 1.5em;
    }

    .boks3-100, .boks7-100{
      width: 33em;
      margin: 1.5em 4.5em 1.5em 4.5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1.5em 1.5em 1.5em 4.5em;
    }

    .boks4-100, .boks11-100{
      height: 29em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1.5em 4.5em 1.5em 1.5em;
    }

    .boks6-100{
      margin: -14.5em 4.5em 1.5em 22.5em;
    }

    .boks12-100 {
      margin: -14.5em 4.5em 1.5em 4.5em;
    }
  }

  @media screen and (max-width: 671px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 14em;
      height: 12em;
    }

    .boks1-100 {
      margin: 2em 1.5em 1.5em 5em;
    }

    .boks2-100{
      margin: 2em 5em 1.5em 1.5em;
    }

    .boks3-100, .boks7-100{
      width: 31em;
      height: 12em;
      margin: 1.5em 5em 1.5em 5em;
    }

    .boks4-100, .boks11-100{
      width: 14em;
      height: 27em;
    } 

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1.5em 1.5em 1.5em 5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1.5em 5em 1.5em 1.5em;
    }

    .boks6-100{
      margin: -13.5em 5em 2em 22em;
    }

    .boks12-100 {
      margin: -13.5em 5em 2em 5em;
    }
  }

  @media screen and (max-width: 655px){
    .boks1-100 {
      margin: 2em 1.5em 1.5em 4.5em;
    }

    .boks2-100{
      margin: 2em 4.5em 1.5em 1.5em;
    }

    .boks3-100, .boks7-100{
      margin: 1.5em 4.5em 1.5em 4.5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1.5em 1.5em 1.5em 4.5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1.5em 4.5em 1.5em 1.5em;
    }

    .boks6-100{
      margin: -13.5em 4.5em 2em 21.5em;
    }

    .boks12-100 {
      margin: -13.5em 5em 2em 4.5em;
    }
  }

  @media screen and (max-width: 639px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 12.5em;
      height: 11.5em;
    }

    .boks1-100 {
      margin: 2em 1.5em 1.5em 5.5em;
    }

    .boks2-100{
      margin: 2em 5.5em 1.5em 1.5em;
    }

    .boks3-100, .boks7-100{
      width: 28em;
      height: 13em;
      margin: 1.5em 5.5em 1.5em 5.5em;
    }

    .boks4-100, .boks11-100{
      width: 12.5em;
      height: 26em;
    } 

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1.5em 1.5em 1.5em 5.5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1.5em 5.5em 1.5em 1.5em;
    }

    .boks6-100{
      margin: -13em 5.5em 2em 21em;
    }

    .boks12-100 {
      margin: -13em 4.5em 2em 5.5em;
    }
  }

  @media screen and (max-width: 623px){
    .boks1-100 {
      margin: 2em 1.5em 1.5em 5em;
    }

    .boks2-100{
      margin: 2em 5em 1.5em 1.5em;
    }

    .boks3-100, .boks7-100{
      margin: 1.5em 5em 1.5em 5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1.5em 1.5em 1.5em 5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1.5em 5em 1.5em 1.5em;
    }

    .boks6-100{
      margin: -13.5em 5em 2em 20.5em;
    }

    .boks12-100 {
      margin: -13.5em 5em 2em 5em;
    }
  }

  @media screen and (max-width: 607px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 12em;
      height: 11em;
    }

    .boks3-100, .boks7-100{
      width: 27em;
      height: 11em;
    }

    .boks4-100, .boks11-100{
      width: 12em;
      height: 25.5em;
    } 

    .boks6-100{
      margin: -12.5em 5em 2em 20em;
    }

    .boks12-100 {
      margin: -13em 4.5em 2em 5em;
    }
  }

  @media screen and (max-width: 591px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 11.5em;
      height: 10.5em;
    }

    .boks3-100, .boks7-100{
      width: 26em;
      height: 10.5em;
    }

    .boks4-100, .boks11-100{
      width: 11.5em;
      height: 24em;
    } 

    .boks6-100{
      margin: -12em 5em 2em 19.5em;
    }

    .boks12-100 {
      margin: -12em 4.5em 2em 5em;
    }
  }

  @media screen and (max-width: 576px){
    .boks1-100 {
      margin: 2em 1.5em 1.5em 4.5em;
    }

    .boks2-100{
      margin: 2em 4.5em 1.5em 1.5em;
    }

    .boks3-100, .boks7-100{
      margin: 1.5em 4.5em 1.5em 4.5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1.5em 1.5em 1.5em 4.5em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1.5em 4.5em 1.5em 1.5em;
    }

    .boks6-100{
      margin: -12em 5em 2em 19em;
    }

    .boks12-100 {
      margin: -12em 5em 2em 4.5em;
    }
  }

  @media screen and (max-width: 559px){
    .boks1-100 {
      margin: 2em 1.5em 1.5em 4em;
    }

    .boks2-100{
      margin: 2em 4em 1.5em 1.5em;
    }

    .boks3-100, .boks7-100{
      margin: 1.5em 4em 1.5em 4em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1.5em 1.5em 1.5em 4em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1.5em 4em 1.5em 1.5em;
    }

    .boks6-100{
      margin: -12em 4em 2em 18.5em;
    }

    .boks12-100 {
      margin: -12em 5em 2em 4em;
    }
  }

  @media screen and (max-width: 543px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 11em;
      height: 10em;
    }

    .boks3-100, .boks7-100{
      width: 25em;
      height: 10em;
    }

    .boks4-100, .boks11-100{
      width: 11em;
      height: 22.5em;
    } 

    .boks6-100{
      margin: -11.5em 4em 2em 18em;
    }

    .boks12-100 {
      margin: -11.5em 5em 2em 4em;
    }
  }

  @media screen and (max-width: 527px){
    .boks1-100 {
      margin: 2em 1em 1em 4em;
    }

    .boks2-100{
      margin: 2em 4em 1em 1em;
    }

    .boks3-100, .boks7-100{
      width: 24em;
      margin: 1em 4em 1em 4em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1em 1em 1em 4em;
    }

    .boks4-100, .boks11-100{
      height: 22em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1em 4em 1em 1em;
    }

    .boks6-100{
      margin: -11em 4em 1em 17em;
    }

    .boks12-100 {
      margin: -11em 5em 1em 4em;
    }
  }

  @media screen and (max-width: 511px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 10.5em;
      height: 9.5em;
    }

    .boks3-100, .boks7-100{
      width: 23em;
      height: 9.5em;
    }

    .boks4-100, .boks11-100{
      width: 10.5em;
      height: 21em;
    } 

    .boks6-100{
      margin: -10.5em 4em 1em 16.5em;
    }

    .boks12-100 {
      margin: -10.5em 5em 1em 4em;
    }
  }

  @media screen and (max-width: 495px){
    .boks1-100 {
      margin: 2em 1em 1em 3.5em;
    }

    .boks2-100{
      margin: 2em 3.5em 1em 1em;
    }

    .boks3-100, .boks7-100{
      width: 23em;
      margin: 1em 3.5em 1em 3.5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1em 1em 1em 3.5em;
    }

    .boks4-100, .boks11-100{
      height: 21em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1em 3.5em 1em 1em;
    }

    .boks6-100{
      margin: -10.5em 3.5em 1em 16em;
    }

    .boks12-100 {
      margin: -10.5em 5em 1em 3.5em;
    }
  }

  @media screen and (max-width: 479px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 10em;
      height: 9em;
    }

    .boks3-100, .boks7-100{
      width: 22em;
      height: 9em;
    }

    .boks4-100, .boks11-100{
      width: 10em;
      height: 20em;
    } 

    .boks6-100{
      margin: -10em 4em 1em 15.5em;
    }

    .boks12-100 {
      margin: -10em 5em 1em 3.5em;
    }
  }

  @media screen and (max-width: 463px){
    .boks1-100 {
      margin: 2em 1em 1em 3em;
    }

    .boks2-100{
      margin: 2em 3em 1em 1em;
    }

    .boks3-100, .boks7-100{
      width: 22em;
      margin: 1em 3em 1em 3em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1em 1em 1em 3em;
    }

    .boks4-100, .boks11-100{
      height: 20em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1em 3em 1em 1em;
    }

    .boks6-100{
      margin: -10em 3.8em 1em 15.2em;
    }

    .boks12-100 {
      margin: -10em 5em 1em 3em;
    }
  }

  @media screen and (max-width: 448px){
    .boks1-100, .boks2-100, .boks5-100, .boks6-100, .boks8-100, .boks9-100, .boks10-100, .boks12-100{
      width: 9.5em;
      height: 8.5em;
    }

    .boks3-100, .boks7-100{
      width: 21em;
      height: 8.5em;
    }

    .boks4-100, .boks11-100{
      width: 9.5em;
      height: 19em;
    } 

    .boks6-100{
      margin: -9.5em 3.5em 1em 14.5em;
    }

    .boks12-100 {
      margin: -9.5em 5em 1em 3em;
    }
  }

  @media screen and (max-width: 431px){
    .boks1-100 {
      margin: 2em 1em 1em 2.5em;
    }

    .boks2-100{
      margin: 2em 2.5em 1em 1em;
    }

    .boks3-100, .boks7-100{
      width: 21em;
      margin: 1em 2.5em 1em 2.5em;
    }

    .boks4-100, .boks8-100, .boks10-100{
      margin: 1em 1em 1em 2.5em;
    }

    .boks4-100, .boks11-100{
      height: 19em;
    }

    .boks5-100, .boks9-100, .boks11-100{
      margin: 1em 2.5em 1em 1em;
    }

    .boks6-100{
      margin: -9.5em 3.5em 1em 14em;
    }

    .boks12-100 {
      margin: -9.5em 5em 1em 2.5em;
    }
  }

  /* mobil */
  @media screen and (max-width: 425px){
    .boks1-100, .boks2-100, .boks3-100, .boks4-100, .boks5-100, .boks6-100, .boks7-100, .boks8-100, .boks9-100, .boks10-100, .boks11-100, .boks12-100{
      height: 8em;
      width: 21em;
      margin: 1em 2.5em 1em 2.5em;
    }
  }

  @media screen and (max-width: 350px){
    .boks1-100, .boks2-100, .boks3-100, .boks4-100, .boks5-100, .boks6-100, .boks7-100, .boks8-100, .boks9-100, .boks10-100, .boks11-100, .boks12-100{
      height: 7em;
      width: 21em;
      margin: 1em 2.5em 1em 2.5em;
    }
  }
</style>